from flask import Flask, render_template, request
from google import genai
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(_name_)

client = genai.Client(
    api_key=os.getenv("GEMINI_API_KEY")
)

@app.route("/", methods=["GET", "POST"])
def home():

    story = ""

    if request.method == "POST":

        idea = request.form["idea"]

        prompt = f"""
Create a simple comic story based on this idea:

{idea}

Create exactly 8 panels.

For each panel provide:

Panel Number:
Scene:
Characters:
Dialogue:
Narration:

Make the story creative, simple and easy to understand.
"""

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )

        story = response.text

    return render_template(
        "index.html",
        story=story
    )


if _name_ == "_main_":
    app.run(debug=True)
