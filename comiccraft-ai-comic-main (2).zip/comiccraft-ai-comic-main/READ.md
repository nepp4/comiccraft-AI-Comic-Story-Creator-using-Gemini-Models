# ComicCraft AI Comic Story Creator

ComicCraft is an AI-powered comic story creator.

## Features

- Generate comic stories using AI
- Create 8-panel comic stories
- Generate character dialogues
- Generate scene descriptions
- Easy-to-use interface

## Technologies

- Python
- Flask
- Gemini AI
- HTML
- CSS

## Project

ComicCraft helps users create creative comic stories from a simple story idea.
